// JS Which needs to add
document.write(	
	'<script src="js/jquery.min.js"></script>'+	
	'<script src="js/jquery.fancybox.min.js"></script>'+	
	'<script src="js/slick.min.js"></script>'+	
	'<script src="js/custom.js"></script>'+	
	'<script src="js/common.js"></script>'+	
	'<script src="js/navigation.js"></script>'
	);